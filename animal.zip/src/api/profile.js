import request from './login'

export default {
  get: () => request.get(`${process.env.VUE_APP_USER_BASE}/profile`),
  signout: () => request.delete(`${process.env.VUE_APP_USER_BASE}/signout`)
}