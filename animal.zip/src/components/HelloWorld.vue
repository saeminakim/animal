<template>
  <v-container>
    <v-row class="text-center">
      <v-col class="mb-4">

        <p class="subheading font-weight-regular">
          여기에 내용을 넣습니다         
        </p>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
  export default {
    name: 'HelloWorld',
  }
</script>
